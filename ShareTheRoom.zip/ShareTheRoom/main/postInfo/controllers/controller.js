var myApp = angular.module('DFWRoomy', []);
myApp.controller('AppCtrl', ['$scope', '$http', function($scope, $http) {
	
    console.log("Hello World from controller");
	var refresh = function(){
		$http.get('/postInfo').success(function(response){
			console.log("I got the data I request");
			console.log(response);
			$scope.houselist = response;
		});
	};
	refresh();
	$scope.PostInfo = function(){
		console.log($scope.house);
		$http.post('/postInfo',$scope.house).success(function(response){
		console.log(response);
		refresh();
	});
	};
}]);