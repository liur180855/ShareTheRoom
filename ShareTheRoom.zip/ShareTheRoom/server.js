var express = require('express');
var app = express();
var mongojs=require('mongojs');
var db = mongojs('ShareDB',['ShareDB']);
var bodyParser = require('body-parser');

app.use(express.static(__dirname + "/main"));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());



app.get('/postInfo',function(req,res){
	console.log("I received a GET request");
	db.ShareDB.find(function(err1,docs){
		console.log(docs);
		res.json(docs);
	});
});

app.post('/postInfo',function(req,res){
	console.log("I received a POST request");
	console.log(req.body);
	db.ShareDB.insert(req.body,function(err,doc){
		res.json(doc);
	});
});

app.listen(3000);
console.log("Server running on port 3000");





















